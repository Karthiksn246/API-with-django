from django.urls import path
from .views import index, ProductListCreateView, ProductUpdateDeleteView, ProductList, ProductDetail

urlpatterns = [
    path('products/', ProductListCreateView.as_view(), name='product-list'),
    path('products/<int:pk>/', ProductUpdateDeleteView.as_view(), name='product-detail'),
    path('', index, name='home'),
]
